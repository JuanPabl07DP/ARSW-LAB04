package edu.eci.arsw.springdemo;

public interface SpellChecker {

	public String checkSpell(String text);
	
}
